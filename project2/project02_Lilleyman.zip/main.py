# Project No: 2
# Author: Ryan Lilleyman
# Description: This is the main function that runs the boggle game.


from boggle import BoggleBoard


def main():
    boggle = BoggleBoard()
    boggle.test_case_one()


if __name__ == "__main__":
    main()
